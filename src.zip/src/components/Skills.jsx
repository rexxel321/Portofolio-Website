import { useEffect, useRef } from "react";
import "./Skills.css";

const skills = [
  { name: "Python", pct: 95 },
  { name: "JavaScript", pct: 90 },
  { name: "React.js", pct: 92 },
  { name: "Node.js", pct: 88 },
  { name: "Flutter", pct: 85 },
  { name: "TensorFlow", pct: 87 },
  { name: "MongoDB", pct: 90 },
  { name: "Firebase", pct: 88 },
];

export default function Skills() {
  const sectionRef = useRef(null);

  useEffect(() => {
    const section = sectionRef.current;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          section.querySelectorAll(".skill-bar-fill").forEach(bar => {
            bar.style.width = bar.getAttribute("data-pct") + "%";
          });
          section.querySelectorAll(".reveal").forEach(el => el.classList.add("visible"));
        }
      },
      { threshold: 0.2 }
    );
    if (section) obs.observe(section);
    return () => obs.disconnect();
  }, []);

  return (
    <section id="skills" className="skills" ref={sectionRef}>
      <div className="container">
        <div className="skills-header reveal">
          <div className="section-badge" style={{ background: "rgba(255,255,255,0.1)", color: "var(--orange)" }}>
            My Skills
          </div>
          <h2 className="section-title" style={{ color: "var(--white)" }}>
            Technical <span>Expertise</span>
          </h2>
          <p className="skills-desc">
            A blend of AI, full-stack web, and mobile development skills built through real-world projects.
          </p>
        </div>
        <div className="skills-grid">
          {skills.map((sk, i) => (
            <div key={sk.name} className={`skill-item reveal delay-${(i % 4) + 1}`}>
              <div className="skill-meta">
                <span className="skill-name">{sk.name}</span>
                <span className="skill-pct">{sk.pct}%</span>
              </div>
              <div className="skill-bar">
                <div
                  className="skill-bar-fill"
                  data-pct={sk.pct}
                  style={{ width: "0%" }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
