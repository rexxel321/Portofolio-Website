import { useState, useEffect } from "react";
import "./Contact.css";

const contactInfo = [
  { icon: "✉️", label: "Email", value: "dhiya@example.com" },
  { icon: "📞", label: "Phone", value: "+62 812 3456 7890" },
  { icon: "📍", label: "Location", value: "Indonesia" },
];

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [toast, setToast] = useState(false);

  const handleChange = e => setForm(p => ({ ...p, [e.target.name]: e.target.value }));
  const handleSubmit = e => {
    e.preventDefault();
    setToast(true);
    setForm({ name: "", email: "", subject: "", message: "" });
    setTimeout(() => setToast(false), 3500);
  };

  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const obs = new IntersectionObserver(
      (entries) => entries.forEach(e => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    els.forEach(el => obs.observe(el));
    return () => obs.disconnect();
  });

  return (
    <section id="contact" className="contact">
      <div className="container">
        <div className="contact-header reveal">
          <div className="section-badge">Get In Touch</div>
          <h2 className="section-title">Let's <span>Talk</span></h2>
          <p className="contact-subtitle">Have a project in mind? Let's build something amazing together.</p>
        </div>
        <div className="contact-grid">
          {/* Info */}
          <div className="contact-info reveal-left">
            <h3 className="info-title">Contact Information</h3>
            <p className="info-desc">Fill out the form and I'll get back to you within 24 hours.</p>
            <div className="info-cards">
              {contactInfo.map(info => (
                <div key={info.label} className="info-card">
                  <span className="info-icon">{info.icon}</span>
                  <div>
                    <p className="info-label">{info.label}</p>
                    <p className="info-value">{info.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Form */}
          <form className="contact-form reveal-right" onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label>Your Name</label>
                <input name="name" value={form.name} onChange={handleChange} placeholder="John Doe" required />
              </div>
              <div className="form-group">
                <label>Email Address</label>
                <input type="email" name="email" value={form.email} onChange={handleChange} placeholder="john@example.com" required />
              </div>
            </div>
            <div className="form-group">
              <label>Subject</label>
              <input name="subject" value={form.subject} onChange={handleChange} placeholder="Project Inquiry" required />
            </div>
            <div className="form-group">
              <label>Message</label>
              <textarea name="message" value={form.message} onChange={handleChange} placeholder="Tell me about your project..." rows={5} required />
            </div>
            <button type="submit" className="btn-primary" style={{ width: "100%", justifyContent: "center" }}>
              SEND MESSAGE →
            </button>
          </form>
        </div>
      </div>

      {/* Toast */}
      <div className={`toast ${toast ? "show" : ""}`}>
        ✅ Message sent! I'll get back to you soon.
      </div>
    </section>
  );
}
