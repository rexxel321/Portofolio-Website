import "./Footer.css";

const navLinks = ["Home", "About", "Services", "Skills", "Projects", "Contact"];

const scrollTo = (id) => {
  document.getElementById(id.toLowerCase())?.scrollIntoView({ behavior: "smooth" });
};

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div className="footer-left">
          <div className="footer-logo">Dhiya<span>.</span></div>
          <p className="footer-tagline">Transforming ideas into intelligent digital solutions.</p>
        </div>
        <div className="footer-links">
          {navLinks.map(link => (
            <button key={link} className="footer-link" onClick={() => scrollTo(link)}>{link}</button>
          ))}
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Muhammad Dhiya Ulhaq. All rights reserved.</p>
      </div>
    </footer>
  );
}
