import { useEffect } from "react";
import "./Services.css";

const services = [
  {
    icon: "🤖",
    title: "AI Solutions",
    desc: "Building intelligent systems using machine learning, NLP, and computer vision to automate and enhance business processes.",
    projects: "15+",
    color: "orange",
  },
  {
    icon: "🌐",
    title: "Web Development",
    desc: "Creating modern, responsive web applications using React, Node.js and the latest frontend technologies.",
    projects: "25+",
    color: "dark",
  },
  {
    icon: "📱",
    title: "Mobile Development",
    desc: "Developing cross-platform mobile apps with Flutter that deliver native performance on iOS and Android.",
    projects: "10+",
    color: "orange",
  },
];

export default function Services() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal, .reveal-left, .reveal-right");
    const obs = new IntersectionObserver(
      (entries) => entries.forEach(e => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.12 }
    );
    els.forEach(el => obs.observe(el));
    return () => obs.disconnect();
  });

  return (
    <section id="services" className="services">
      <div className="container">
        <div className="services-header reveal">
          <div className="section-badge">What I Do</div>
          <h2 className="section-title">My <span>Services</span></h2>
        </div>
        <div className="services-grid">
          {services.map((svc, i) => (
            <div key={svc.title} className={`service-card ${svc.color} reveal delay-${i + 1}`}>
              <div className="svc-icon">{svc.icon}</div>
              <h3 className="svc-title">{svc.title}</h3>
              <p className="svc-desc">{svc.desc}</p>
              <div className="svc-footer">
                <span className="svc-count">{svc.projects} Projects</span>
                <span className="svc-arrow">→</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
