import { useEffect } from "react";
import "./About.css";

const stats = [
  { icon: "💼", number: "50+", label: "Projects Completed" },
  { icon: "👥", number: "30+", label: "Satisfied Clients" },
  { icon: "🏆", number: "3+", label: "Years Of Experience" },
];

const experiences = [
  {
    num: 1,
    period: "2023 – Present",
    title: "AI Developer",
    company: "Tech Innovators",
    desc: "Leading AI integration projects and developing machine learning models",
  },
  {
    num: 2,
    period: "2022 – 2023",
    title: "Full Stack Developer",
    company: "Digital Solutions",
    desc: "Built scalable web applications using MERN stack",
  },
  {
    num: 3,
    period: "2021 – 2022",
    title: "Mobile Developer",
    company: "App Studio",
    desc: "Developed cross-platform mobile applications with Flutter",
  },
];

export default function About() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal, .reveal-left, .reveal-right");
    const obs = new IntersectionObserver(
      (entries) => entries.forEach(e => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.12 }
    );
    els.forEach(el => obs.observe(el));
    return () => obs.disconnect();
  });

  return (
    <section id="about" className="about">
      <div className="container">
        <div className="about-header reveal">
          <div className="section-badge">About Me</div>
          <h2 className="section-title">Who Am I?</h2>
          <p className="about-desc">
            I'm a passionate developer specializing in AI integration, web development, and mobile applications.
            With a strong foundation in modern technologies, I create innovative solutions that bridge the gap
            between artificial intelligence and user experience.
          </p>
        </div>

        {/* Stats */}
        <div className="stats-grid">
          {stats.map((s, i) => (
            <div key={s.label} className={`stat-card reveal delay-${i + 1}`}>
              <div className="stat-icon">{s.icon}</div>
              <div className="stat-number">{s.number}</div>
              <div className="stat-label">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Work experience */}
        <div className="experience reveal">
          <h3 className="exp-title">Work Experience</h3>
          <div className="exp-list">
            {experiences.map((exp, i) => (
              <div key={exp.num} className={`exp-item reveal delay-${i + 1}`}>
                <div className="exp-num">{exp.num}</div>
                <div className="exp-card">
                  <span className="exp-period">{exp.period}</span>
                  <h4 className="exp-role">{exp.title}</h4>
                  <span className="exp-company">{exp.company}</span>
                  <p className="exp-desc">{exp.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
