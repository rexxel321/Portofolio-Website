import { useState, useEffect } from "react";
import "./Projects.css";

const categories = ["All", "AI Solutions", "Web Development", "Mobile Development"];

const projects = [
  {
    title: "AI Chat Assistant",
    category: "AI Solutions",
    desc: "Intelligent chatbot powered by NLP with context understanding",
    img: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=600&q=80",
  },
  {
    title: "E-Commerce Platform",
    category: "Web Development",
    desc: "Full-stack MERN e-commerce with real-time inventory management",
    img: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&q=80",
  },
  {
    title: "Fitness Tracker App",
    category: "Mobile Development",
    desc: "Cross-platform Flutter app with health monitoring features",
    img: "https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?w=600&q=80",
  },
  {
    title: "Image Recognition API",
    category: "AI Solutions",
    desc: "Computer vision model for real-time object detection",
    img: "https://images.unsplash.com/photo-1655720828018-edd2daec9349?w=600&q=80",
  },
  {
    title: "Portfolio Dashboard",
    category: "Web Development",
    desc: "React-based analytics dashboard with interactive charts",
    img: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&q=80",
  },
  {
    title: "Food Delivery App",
    category: "Mobile Development",
    desc: "Flutter app with real-time order tracking and payment integration",
    img: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&q=80",
  },
];

export default function Projects() {
  const [active, setActive] = useState("All");

  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const obs = new IntersectionObserver(
      (entries) => entries.forEach(e => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    els.forEach(el => obs.observe(el));
    return () => obs.disconnect();
  });

  const filtered = active === "All" ? projects : projects.filter(p => p.category === active);

  return (
    <section id="projects" className="projects">
      <div className="container">
        <div className="projects-header reveal">
          <div className="section-badge">Portfolio</div>
          <h2 className="section-title">My <span>Projects</span></h2>
        </div>
        <div className="filter-btns reveal">
          {categories.map(cat => (
            <button
              key={cat}
              className={`filter-btn ${active === cat ? "active" : ""}`}
              onClick={() => setActive(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="projects-grid">
          {filtered.map((p, i) => (
            <div key={p.title} className={`project-card reveal delay-${(i % 3) + 1}`}>
              <div className="project-img-wrap">
                <img src={p.img} alt={p.title} className="project-img" />
                <div className="project-overlay">
                  <span className="overlay-icon">↗</span>
                </div>
              </div>
              <div className="project-info">
                <span className="project-cat">{p.category}</span>
                <h4 className="project-name">{p.title}</h4>
                <p className="project-desc">{p.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
