import React from 'react'
import Header from './components/Header'
import Home from './pages/Home'
import useScrollReveal from './hooks/useScrollReveal'

export default function App() {
  useScrollReveal()
  
  return (
    <div>
      <Header />
      <Home />
    </div>
  )
}
